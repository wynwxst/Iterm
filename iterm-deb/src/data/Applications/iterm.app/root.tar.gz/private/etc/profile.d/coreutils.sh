alias ls="ls -Fb --color=auto -T 0"
eval "$(dircolors -b)"
export CLICOLOR=
